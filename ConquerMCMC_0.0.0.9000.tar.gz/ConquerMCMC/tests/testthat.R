library(testthat)
library(ConquerMCMC)

test_check("ConquerMCMC")

